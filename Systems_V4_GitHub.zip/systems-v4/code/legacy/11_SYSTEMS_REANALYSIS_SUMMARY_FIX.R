# ============================================================================
# 11_SYSTEMS_REANALYSIS_SUMMARY_FIX.R
# Fix: use base::nrow and class-independent print(as.data.frame(...)).
# Chinese cultural names in English, 1800-2022
# Systems-science extension: composition, observable state transitions,
# and time-varying cultural-domain x naming-pathway associations.
#
# INPUT: FINAL_SUBMISSION_ANNUAL_DATA.csv (the audited FINAL version).
# OUTPUT: ROOT_DIR/Systems_Reanalysis_Outputs/ and optional ZIP.
#
# IMPORTANT: This is a NEW systems-specific analytical lens. It does NOT
# reproduce the old manuscript's RQ1 definition: full 10-year eligibility
# is now mandatory. Do not copy old manuscript values into the new paper.
# ============================================================================

# 0. USER SETTINGS -----------------------------------------------------------
ROOT_DIR <- normalizePath(getwd(), winslash = "/")
INPUT_FILE <- file.path(ROOT_DIR, "data", "annual", "FINAL_SUBMISSION_ANNUAL_DATA.csv")
OUT_DIR <- file.path(ROOT_DIR, "generated", "longitudinal")

# A full decade must contain all ten calendar years of valid observations.
ACTIVE_POSITIVE_YEARS <- 3L    # main analysis: positive in >=3 of 10 years
RAREFY_N <- 20L              # fixed-size subsample of ACTIVE terms
B_RAREFY <- 600L            # repeated without-replacement subsamples
B_DIVERSITY_BOOT <- 600L    # bootstrap intervals, resampled at term level
B_ASSOC_BOOT <- 800L        # shared term-level bootstrap across periods
B_ASSOC_MONTE_CARLO <- 9999L

# Sensitivities, using the same valid-year coverage:
ACTIVITY_THRESHOLDS <- c(2L, 3L, 4L)
FIXED_COHORT_DECADE <- 1900L
MIN_ACTIVE_FOR_STRUCTURE_COMPARISON <- 20L
MIN_PERIOD_ACTIVE_TERMS <- 30L
MIN_PERIOD_PER_PATH <- 5L
PERIOD_MIN_FULL_DECADES <- 2L
PERIOD_ACTIVE_SHARE <- 0.50
SET_SEED <- 20261107L

# Pre-specified, non-overlapping periods. 2020-2022 is NOT a full decade.
PERIODS <- data.frame(
  period = c("1800-1899", "1900-1949", "1950-1979", "1980-2019"),
  from = c(1800L, 1900L, 1950L, 1980L),
  to = c(1899L, 1949L, 1979L, 2019L),
  stringsAsFactors = FALSE
)

# 1. PACKAGES AND UTILITIES -------------------------------------------------
packages <- c("readr", "dplyr", "tidyr", "ggplot2", "tibble")
needed <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(needed)) {
  message("Installing missing CRAN binary packages: ", paste(needed, collapse = ", "))
  install.packages(needed, repos = "https://cloud.r-project.org")
}
suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(tibble)
})
# Check actual write access. dir.create() does not throw if creation fails.
# On Windows, the project path may be read-only or blocked by sync/security.
choose_writable_output_dir <- function(preferred) {
  home <- path.expand("~")
  candidates <- unique(c(
    preferred,
    file.path(home, "Documents", "Systems_Reanalysis_Outputs"),
    file.path(home, "Systems_Reanalysis_Outputs")
  ))
  for (candidate in candidates) {
    suppressWarnings(try(dir.create(candidate, recursive = TRUE,
                                    showWarnings = FALSE), silent = TRUE))
    if (!dir.exists(candidate)) next
    # If previous results exist, make a fresh output directory to avoid
    # overwriting a CSV still open in Excel.
    if (file.exists(file.path(candidate, "01_term_input_coverage.csv"))) {
      stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
      candidate <- file.path(dirname(candidate),
                             paste0(basename(candidate), "_rerun_", stamp))
      suppressWarnings(try(dir.create(candidate, recursive = TRUE,
                                      showWarnings = FALSE), silent = TRUE))
      if (!dir.exists(candidate)) next
    }
    probe <- tempfile(".systems_write_test_", tmpdir = candidate)
    writable <- tryCatch({
      writeLines("ok", probe, useBytes = TRUE)
      TRUE
    }, error = function(e) FALSE)
    if (file.exists(probe)) unlink(probe)
    if (isTRUE(writable)) {
      return(normalizePath(candidate, winslash = "/", mustWork = TRUE))
    }
  }
  stop("Could not find a writable output directory. Close open CSV files, " ,
       "or set OUT_DIR to a writable folder such as C:/Users/.../Documents/Systems_Reanalysis_Outputs.")
}
OUT_DIR <- choose_writable_output_dir(OUT_DIR)
message("OUTPUT DIRECTORY (all files): ", OUT_DIR)
set.seed(SET_SEED)

save_csv <- function(x, filename) {
  target <- file.path(OUT_DIR, filename)
  tryCatch(readr::write_csv(x, target, na = ""), error = function(e) {
    stop("Cannot save ", filename, " to ", OUT_DIR, ": ",
         conditionMessage(e), ". Check permissions and close Excel.", call. = FALSE)
  })
}
write_report <- function(lines, filename) {
  writeLines(enc2utf8(lines), file.path(OUT_DIR, filename), useBytes = TRUE)
}
fmt <- function(x, digits = 3) ifelse(is.na(x), "NA", format(round(x, digits), nsmall=digits, trim=TRUE))

# Do not accidentally select an obsolete semantic-clean or boundary file.
if (is.na(INPUT_FILE) || !nzchar(INPUT_FILE)) {
  direct <- c(
    file.path(ROOT_DIR, "Systems_Analysis_Starter", "FINAL_SUBMISSION_OUTPUTS", "FINAL_SUBMISSION_ANNUAL_DATA.csv"),
    file.path(ROOT_DIR, "FINAL_SUBMISSION_OUTPUTS", "FINAL_SUBMISSION_ANNUAL_DATA.csv"),
    file.path(ROOT_DIR, "准备投稿版", "FINAL_SUBMISSION_ANNUAL_DATA.csv"),
    file.path(ROOT_DIR, "FINAL_SUBMISSION_ANNUAL_DATA.csv"),
    file.path(ROOT_DIR, "data", "04_final_analysis", "FINAL_SUBMISSION_ANNUAL_DATA.csv")
  )
  present <- direct[file.exists(direct)]
  if (length(present) > 0L) {
    INPUT_FILE <- present[1L]
  } else {
    hits <- list.files(ROOT_DIR, pattern = "^FINAL_SUBMISSION_ANNUAL_DATA\\.csv$",
                       full.names = TRUE, recursive = TRUE, ignore.case = TRUE)
    hits <- hits[!grepl("archive|backup|old", hits, ignore.case = TRUE)]
    if (length(hits) == 1L) INPUT_FILE <- hits
    if (length(hits) > 1L) {
      stop("Found multiple FINAL_SUBMISSION_ANNUAL_DATA.csv files. Set INPUT_FILE explicitly:\n",
           paste(hits, collapse = "\n"))
    }
  }
}
if (is.na(INPUT_FILE) || !file.exists(INPUT_FILE)) {
  if (interactive()) {
    message("Please select the FINAL_SUBMISSION_ANNUAL_DATA.csv file in the file picker.")
    INPUT_FILE <- file.choose()
  }
}
if (is.na(INPUT_FILE) || !file.exists(INPUT_FILE)) {
  stop("Cannot find FINAL_SUBMISSION_ANNUAL_DATA.csv. Unzip the complete Systems_Analysis_Starter.zip, then select its CSV, or set INPUT_FILE to the full CSV path.")
}
message("Reading final audited annual file: ", INPUT_FILE)

raw <- readr::read_csv(INPUT_FILE, show_col_types = FALSE, progress = FALSE)
required <- c("row_id", "term", "pathway", "cultural_domain", "year", "frequency",
              "audited_valid_from")
missing_cols <- setdiff(required, names(raw))
if (length(missing_cols)) stop("Missing required fields: ", paste(missing_cols, collapse=", "))

annual <- raw %>%
  transmute(
    row_id = as.character(row_id), term = as.character(term),
    pathway = as.character(pathway), cultural_domain = as.character(cultural_domain),
    year = as.integer(year), frequency = as.numeric(frequency),
    audited_valid_from = as.integer(audited_valid_from)
  ) %>% arrange(row_id, year)

if (anyNA(annual[, c("row_id", "term", "pathway", "cultural_domain",
                      "year", "frequency", "audited_valid_from")])) {
  stop("Final annual data contain missing essential values; inspect the input before analysis.")
}
if (any(annual$frequency < 0) || any(!is.finite(annual$frequency))) {
  stop("Frequency must be non-negative and finite.")
}
if (any(annual$year < 1800 | annual$year > 2022)) {
  stop("Input contains years outside 1800-2022.")
}
if (any(duplicated(annual[c("row_id", "year")]))) {
  stop("Duplicate row_id-year combinations found.")
}
if (any(annual$year < annual$audited_valid_from)) {
  stop("Some yearly data precede audited_valid_from: final audit input inconsistent.")
}
if (!all(annual$pathway %in% c("source_form", "pure_calque", "mixed"))) {
  stop("Unexpected pathway values; expected source_form / pure_calque / mixed.")
}

meta_consistency <- annual %>% group_by(row_id) %>% summarise(
  n_terms = n_distinct(term), n_paths = n_distinct(pathway),
  n_domains = n_distinct(cultural_domain), n_starts = n_distinct(audited_valid_from),
  .groups = "drop"
)
if (any(meta_consistency$n_terms != 1L | meta_consistency$n_paths != 1L |
        meta_consistency$n_domains != 1L | meta_consistency$n_starts != 1L)) {
  stop("Some row_id values have inconsistent metadata across years.")
}

meta <- annual %>% group_by(row_id) %>% summarise(
  term = first(term), pathway = first(pathway),
  cultural_domain = first(cultural_domain),
  audited_valid_from = first(audited_valid_from),
  first_observed_year = min(year), last_observed_year = max(year),
  n_observed_years = n(), .groups = "drop"
)

coverage_gaps <- annual %>% group_by(row_id) %>% summarise(
  gaps = sum(diff(sort(year)) != 1L), .groups = "drop"
)
meta <- left_join(meta, coverage_gaps, by="row_id")
save_csv(meta, "01_term_input_coverage.csv")
if (any(meta$gaps > 0L)) {
  warning("There are gaps inside valid annual spans. Full-decade eligibility will exclude affected decades.")
}

if (n_distinct(annual$row_id) != 154L || nrow(annual) != 27439L) {
  warning("Input dimensions differ from the earlier manuscript (154 terms, 27,439 rows). ",
          "Script will continue with the actual FINAL input, but reconcile versions before writing.")
}

ALL_DECADES <- seq.int(1800L, 2010L, by = 10L)
ALL_DOMAINS <- sort(unique(meta$cultural_domain))
PATHS <- c("source_form", "pure_calque", "mixed")

# 2. DEFINE FULL-DECADE RISK SET --------------------------------------------
# A term is eligible for a decade only when all ten valid yearly records exist.
# Years prior to semantic/chronological validity are NOT implicit zeros.
decade_observed <- annual %>% filter(year <= 2019L) %>%
  mutate(decade = as.integer(floor(year / 10) * 10)) %>%
  group_by(row_id, decade) %>% summarise(
    n_recorded_years = n_distinct(year),
    n_positive_years = sum(frequency > 0),
    sum_frequency = sum(frequency),
    .groups = "drop"
  )

grid <- tidyr::expand_grid(row_id = meta$row_id, decade = ALL_DECADES) %>%
  left_join(meta, by = "row_id") %>%
  left_join(decade_observed, by=c("row_id", "decade")) %>%
  mutate(
    n_recorded_years = coalesce(as.integer(n_recorded_years), 0L),
    n_positive_years = coalesce(as.integer(n_positive_years), 0L),
    sum_frequency = coalesce(sum_frequency, 0),
    eligible = n_recorded_years == 10L,
    active = if_else(eligible, n_positive_years >= ACTIVE_POSITIVE_YEARS, NA),
    state = case_when(!eligible ~ "not_observable",
                      active ~ "active", TRUE ~ "observable_inactive")
  ) %>% arrange(row_id, decade)

# Each full decade with a completely valid time series uses the same fixed
# >=3/10 threshold. This differs from the old RQ1 rule for partial decades.
save_csv(grid, "02_term_decade_panel.csv")

# 3. OBSERVED STRUCTURE AND UNCERTAINTY -------------------------------------
structure_vec <- function(d) {
  n <- nrow(d)
  keys <- c("H_domain", "effective_domains", "HHI_domain", "inverse_HHI",
            "domain_richness", "H_joint", "effective_joint_cells",
            "source_form_share", "pure_calque_share", "mixed_share")
  if (!n) return(stats::setNames(rep(NA_real_, length(keys)), keys))
  pv <- as.numeric(table(d$cultural_domain)) / n
  pv <- pv[pv > 0]
  joint <- as.numeric(table(paste(d$cultural_domain, d$pathway, sep="||"))) / n
  joint <- joint[joint > 0]
  h <- -sum(pv * log(pv))
  hj <- -sum(joint * log(joint))
  c(H_domain = h, effective_domains = exp(h), HHI_domain = sum(pv^2),
    inverse_HHI = 1 / sum(pv^2), domain_richness = length(pv),
    H_joint = hj, effective_joint_cells = exp(hj),
    source_form_share = mean(d$pathway == "source_form"),
    pure_calque_share = mean(d$pathway == "pure_calque"),
    mixed_share = mean(d$pathway == "mixed"))
}

ci <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) < 2L) return(c(NA_real_, NA_real_))
  unname(stats::quantile(x, c(0.025, 0.975), na.rm=TRUE))
}

obs_rows <- list()
rare_rows <- list()
for (dd in ALL_DECADES) {
  d <- grid %>% filter(decade == dd, eligible, active %in% TRUE)
  n <- nrow(d)
  eligible_n <- sum(grid$eligible[grid$decade == dd])
  m <- structure_vec(d)
  boot_ci_eff <- c(NA_real_, NA_real_)
  boot_ci_joint <- c(NA_real_, NA_real_)
  if (n >= 2L) {
    draws <- replicate(B_DIVERSITY_BOOT,
                       structure_vec(d[sample.int(n, n, replace=TRUE), , drop=FALSE]))
    boot_ci_eff <- ci(draws["effective_domains", ])
    boot_ci_joint <- ci(draws["effective_joint_cells", ])
  }
  obs_rows[[as.character(dd)]] <- data.frame(
    decade=dd, n_eligible=eligible_n, n_active=n, activity_fraction=if(eligible_n>0)n/eligible_n else NA_real_,
    as.list(m), effective_domains_boot_low=boot_ci_eff[1],
    effective_domains_boot_high=boot_ci_eff[2],
    effective_joint_boot_low=boot_ci_joint[1],
    effective_joint_boot_high=boot_ci_joint[2],
    stringsAsFactors=FALSE, check.names=FALSE
  )
  if (n >= RAREFY_N) {
    r <- replicate(B_RAREFY,
                   structure_vec(d[sample.int(n, RAREFY_N, replace=FALSE), , drop=FALSE]))
    rare_rows[[as.character(dd)]] <- data.frame(
      decade=dd, n_active=n, rarefy_n=RAREFY_N,
      effective_domains_mean=mean(r["effective_domains", ]),
      effective_domains_low=ci(r["effective_domains", ])[1],
      effective_domains_high=ci(r["effective_domains", ])[2],
      HHI_mean=mean(r["HHI_domain", ]),
      HHI_low=ci(r["HHI_domain", ])[1],
      HHI_high=ci(r["HHI_domain", ])[2],
      effective_joint_mean=mean(r["effective_joint_cells", ]),
      effective_joint_low=ci(r["effective_joint_cells", ])[1],
      effective_joint_high=ci(r["effective_joint_cells", ])[2]
    )
  } else {
    rare_rows[[as.character(dd)]] <- data.frame(
      decade=dd, n_active=n, rarefy_n=RAREFY_N,
      effective_domains_mean=NA_real_, effective_domains_low=NA_real_,
      effective_domains_high=NA_real_, HHI_mean=NA_real_, HHI_low=NA_real_,
      HHI_high=NA_real_, effective_joint_mean=NA_real_,
      effective_joint_low=NA_real_, effective_joint_high=NA_real_
    )
  }
}
structure_decade <- dplyr::bind_rows(obs_rows)
rarefied <- dplyr::bind_rows(rare_rows)
save_csv(structure_decade, "03_structure_by_decade.csv")
save_csv(rarefied, "04_rarefied_diversity_by_decade.csv")

# Preserve the full domain/pathway composition behind the system indices.
# Each active term contributes once per full decade.
domain_decade <- grid %>% filter(eligible, active %in% TRUE) %>%
  count(decade, cultural_domain, name="n_active_domain") %>%
  complete(decade=ALL_DECADES, cultural_domain=ALL_DOMAINS,
           fill=list(n_active_domain=0L)) %>%
  left_join(structure_decade %>% select(decade,n_active),by="decade") %>%
  mutate(domain_share=if_else(n_active>0,n_active_domain/n_active,NA_real_))
save_csv(domain_decade, "04B_domain_composition_by_decade.csv")

joint_decade <- grid %>% filter(eligible,active %in% TRUE) %>%
  count(decade,cultural_domain,pathway,name="n_active") %>%
  complete(decade=ALL_DECADES,cultural_domain=ALL_DOMAINS,
           pathway=PATHS,fill=list(n_active=0L))
save_csv(joint_decade, "04C_domain_pathway_joint_by_decade.csv")

# A cohort with valid records from the same baseline decade onward separates
# vocabulary additions to the eligible pool from within-cohort activation.
cohort_ids <- grid %>% filter(decade == FIXED_COHORT_DECADE, eligible) %>% pull(row_id)
cohort_structure <- lapply(ALL_DECADES[ALL_DECADES >= FIXED_COHORT_DECADE], function(dd) {
  ddg <- grid %>% filter(decade == dd, row_id %in% cohort_ids)
  active_d <- ddg %>% filter(eligible, active %in% TRUE)
  data.frame(decade=dd, cohort_terms=length(cohort_ids),
             n_cohort_eligible=sum(ddg$eligible), n_cohort_active=nrow(active_d),
             as.list(structure_vec(active_d)), check.names=FALSE)
}) %>% dplyr::bind_rows()
save_csv(cohort_structure, "05_fixed_1900_cohort_structure.csv")

# Jensen-Shannon divergence of adjacent decades in domain composition.
jsd <- function(a, b) {
  m <- (a+b)/2
  kl <- function(p, q) sum(p[p>0] * log2(p[p>0]/q[p>0]))
  0.5*kl(a,m) + 0.5*kl(b,m)
}
shares <- lapply(ALL_DECADES, function(dd) {
  d <- grid %>% filter(decade==dd, eligible, active %in% TRUE)
  v <- as.numeric(table(factor(d$cultural_domain, levels=ALL_DOMAINS)))
  if (sum(v) == 0) v[] <- NA_real_ else v <- v/sum(v)
  v
})
js <- lapply(seq_along(ALL_DECADES)[-1], function(i) {
  n0 <- structure_decade$n_active[i-1]
  n1 <- structure_decade$n_active[i]
  data.frame(from_decade=ALL_DECADES[i-1], to_decade=ALL_DECADES[i],
    n_active_from=n0,n_active_to=n1,
    JS_divergence_bits=if(n0>=MIN_ACTIVE_FOR_STRUCTURE_COMPARISON &&
                          n1>=MIN_ACTIVE_FOR_STRUCTURE_COMPARISON)
                       jsd(shares[[i-1]],shares[[i]]) else NA_real_,
    status=if(n0>=MIN_ACTIVE_FOR_STRUCTURE_COMPARISON &&
              n1>=MIN_ACTIVE_FOR_STRUCTURE_COMPARISON) "descriptive" else "low_support"
  )
}) %>% dplyr::bind_rows()
save_csv(js, "06_adjacent_decade_JS_divergence.csv")

# 4. STOCK-FLOW ACCOUNTING OF OBSERVABLE STATES -----------------------------
# 'newly_observable_active' reflects the analysis window, NOT necessarily
# historical borrowing/entry. 'first_activation' requires a prior FULL valid
# decade of observed inactivity. No causal mechanism is inferred.
assign_events <- function(g, threshold=ACTIVE_POSITIVE_YEARS) {
  g %>% arrange(row_id, decade) %>% group_by(row_id) %>%
    mutate(
      active = if_else(eligible, n_positive_years >= threshold, NA),
      prior_eligible = lag(eligible, default=FALSE),
      prior_active = lag(active),
      ever_active_before = lag(cummax(as.integer(active %in% TRUE)), default=0L)>0L,
      event = case_when(
        !eligible ~ "not_observable",
        active %in% TRUE & !prior_eligible ~ "newly_observable_active",
        active %in% TRUE & prior_eligible & prior_active %in% TRUE ~ "retained_active",
        active %in% TRUE & prior_eligible & prior_active %in% FALSE & ever_active_before ~ "reactivated",
        active %in% TRUE & prior_eligible & prior_active %in% FALSE ~ "first_activation",
        active %in% FALSE & prior_eligible & prior_active %in% TRUE ~ "became_inactive",
        TRUE ~ "observable_inactive"
      )
    ) %>% ungroup()
}

flow_table <- function(p) {
  p %>% group_by(decade) %>% summarise(
    eligible_terms=sum(eligible), active_stock=sum(active %in% TRUE),
    retained_active=sum(event=="retained_active"),
    first_activation=sum(event=="first_activation"),
    reactivated=sum(event=="reactivated"),
    newly_observable_active=sum(event=="newly_observable_active"),
    became_inactive=sum(event=="became_inactive"),
    lost_eligibility_active=sum(!eligible & prior_eligible & prior_active %in% TRUE),
    .groups="drop"
  ) %>% arrange(decade) %>% mutate(
    previous_active_stock=lag(active_stock),
    predicted_stock=if_else(is.na(previous_active_stock),NA_real_,
      previous_active_stock + first_activation + reactivated +
      newly_observable_active - became_inactive - lost_eligibility_active),
    reconciliation_error=active_stock-predicted_stock,
    active_fraction=active_stock/eligible_terms
  )
}
panel_events <- assign_events(grid)
flow <- flow_table(panel_events)
if(any(abs(flow$reconciliation_error[is.finite(flow$reconciliation_error)])>0)) {
  stop("Stock-flow identity failed. Check validity/eligibility transition definitions.")
}
save_csv(panel_events, "07_term_decade_events.csv")
save_csv(flow, "08_system_stock_flow.csv")

sensitivity_activity <- lapply(ACTIVITY_THRESHOLDS, function(k) {
  q <- flow_table(assign_events(grid,k))
  q$positive_years_threshold <- k
  q
}) %>% dplyr::bind_rows()
save_csv(sensitivity_activity, "09_activity_threshold_sensitivity.csv")

# 2020-2022 is a three-year descriptive snapshot ONLY, not part of 10y flows.
recent <- annual %>% filter(year>=2020L,year<=2022L) %>%
  group_by(row_id) %>% summarise(
    n_2020_2022_years=n_distinct(year),
    positive_years_2020_2022=sum(frequency>0),
    .groups="drop"
  ) %>% right_join(meta %>% select(row_id,term,pathway,cultural_domain),by="row_id") %>%
  mutate(full_three_year_coverage=coalesce(n_2020_2022_years,0L)==3L,
         active_1of3=if_else(full_three_year_coverage, positive_years_2020_2022>=1L, NA),
         active_2of3=if_else(full_three_year_coverage, positive_years_2020_2022>=2L, NA))
save_csv(recent, "10_2020_2022_descriptive_only.csv")

# 5. DYNAMIC DOMAIN x PATHWAY STRUCTURE -------------------------------------
# Count each TERM once per time block. Require >=2 full eligible decades;
# period-active = active in >=50% of its full eligible decades. This avoids
# counting 100-year periods four times more heavily than 25-year periods.
term_period <- panel_events %>% filter(eligible) %>%
  mutate(period=case_when(
    decade>=1800L & decade<=1890L ~ "1800-1899",
    decade>=1900L & decade<=1940L ~ "1900-1949",
    decade>=1950L & decade<=1970L ~ "1950-1979",
    decade>=1980L & decade<=2010L ~ "1980-2019",
    TRUE ~ NA_character_
  )) %>% filter(!is.na(period)) %>%
  group_by(row_id,term,pathway,cultural_domain,period) %>%
  summarise(n_full_eligible_decades=n(),
            n_active_decades=sum(active %in% TRUE), .groups="drop") %>%
  mutate(activity_share=n_active_decades/n_full_eligible_decades,
         eligible_for_period=n_full_eligible_decades>=PERIOD_MIN_FULL_DECADES,
         period_active=eligible_for_period & activity_share>=PERIOD_ACTIVE_SHARE)
save_csv(term_period, "11_term_period_panel.csv")

assoc_input <- term_period %>%
  filter(eligible_for_period,period_active,pathway %in% c("source_form","pure_calque"))

# Bias-corrected Cramer's V is preferable for comparing periods with
# unequal N and different numbers of populated domain categories.
assoc_from_table <- function(tab) {
  tab <- as.matrix(tab)
  tab <- tab[rowSums(tab)>0,colSums(tab)>0,drop=FALSE]
  n <- sum(tab)
  if(n<3 || nrow(tab)<2 || ncol(tab)<2) {
    return(c(n=n, V_raw=NA_real_, V_bias_corrected=NA_real_, MI_bits=NA_real_))
  }
  p <- tab/n
  pr <- rowSums(p); pc <- colSums(p)
  expected <- outer(pr,pc)
  chi <- sum((tab-n*expected)^2 / (n*expected))
  phi2 <- chi/n
  V_raw <- sqrt(phi2/min(nrow(tab)-1,ncol(tab)-1))
  phi2_corrected <- max(0,phi2-((nrow(tab)-1)*(ncol(tab)-1))/(n-1))
  r_adj <- nrow(tab)-((nrow(tab)-1)^2)/(n-1)
  c_adj <- ncol(tab)-((ncol(tab)-1)^2)/(n-1)
  denom <- min(r_adj-1,c_adj-1)
  V_adj <- if(denom>0) sqrt(phi2_corrected/denom) else NA_real_
  MI <- sum(p[p>0]*log2(p[p>0]/expected[p>0]))
  c(n=n,V_raw=V_raw,V_bias_corrected=V_adj,MI_bits=MI)
}

make_assoc_tab <- function(d, weights=NULL) {
  if(is.null(weights)) weights <- rep(1L, base::nrow(d))
  tab <- matrix(0, nrow=length(ALL_DOMAINS),ncol=2,
                dimnames=list(ALL_DOMAINS,c("source_form","pure_calque")))
  for(i in seq_len(nrow(d))) {
    tab[d$cultural_domain[i],d$pathway[i]] <-
      tab[d$cultural_domain[i],d$pathway[i]]+weights[i]
  }
  tab
}

assoc_rows <- list(); support_rows <- list(); period_cells <- list()
for(kk in seq_len(nrow(PERIODS))) {
  pn <- PERIODS$period[kk]
  dd <- assoc_input %>% filter(period==pn)
  tb <- make_assoc_tab(dd)
  ar <- assoc_from_table(tb)
  nsource <- sum(dd$pathway=="source_form")
  ncalque <- sum(dd$pathway=="pure_calque")
  sufficient <- nrow(dd)>=MIN_PERIOD_ACTIVE_TERMS &&
                nsource>=MIN_PERIOD_PER_PATH && ncalque>=MIN_PERIOD_PER_PATH &&
                sum(rowSums(tb)>0)>=2L
  pval <- NA_real_
  if(sufficient) {
    core <- tb[rowSums(tb)>0,colSums(tb)>0,drop=FALSE]
    pval <- suppressWarnings(stats::chisq.test(
      core, simulate.p.value=TRUE, B=B_ASSOC_MONTE_CARLO)$p.value)
  }
  assoc_rows[[pn]] <- data.frame(
    period=pn, n_binary_terms=nrow(dd), n_source_form=nsource,
    n_pure_calque=ncalque,n_domains_present=sum(rowSums(tb)>0),
    V_raw=unname(ar["V_raw"]),
    V_bias_corrected=unname(ar["V_bias_corrected"]),
    MI_bits=unname(ar["MI_bits"]), p_monte_carlo=pval,
    inference_status=if(sufficient) "inference_allowed" else "descriptive_only_sparse",
    stringsAsFactors=FALSE
  )
  support_rows[[pn]] <- term_period %>% filter(period==pn) %>%
    summarise(period=pn, n_full_period_eligible=sum(eligible_for_period),
              n_period_active_all_paths=sum(period_active),
              n_undercovered=sum(!eligible_for_period),
              .groups="drop")
  cells <- as.data.frame(as.table(tb),stringsAsFactors=FALSE)
  names(cells) <- c("cultural_domain","pathway","n")
  cells$period <- pn
  period_cells[[pn]] <- cells
}
assoc_metrics <- dplyr::bind_rows(assoc_rows)
save_csv(dplyr::bind_rows(support_rows), "12_period_support.csv")
save_csv(dplyr::bind_rows(period_cells), "13_period_domain_path_cells.csv")
save_csv(assoc_metrics, "14_period_association_metrics.csv")

# Cluster bootstrap at TERM level: the same sampled term weights are used
# in every period, preserving within-term dependence across time.
all_ids <- meta$row_id
period_order <- PERIODS$period
assoc_boot <- vector("list",B_ASSOC_BOOT)
for(b in seq_len(B_ASSOC_BOOT)) {
  ix <- sample.int(length(all_ids),length(all_ids),replace=TRUE)
  term_weights <- tabulate(ix,nbins=length(all_ids))
  names(term_weights) <- all_ids
  one <- lapply(period_order,function(pn) {
    dd <- assoc_input %>% filter(period==pn)
    w <- term_weights[dd$row_id]
    tab <- make_assoc_tab(dd,as.numeric(w))
    measures <- assoc_from_table(tab)
    data.frame(replicate=b,period=pn,
               V_bias_corrected=unname(measures["V_bias_corrected"]),
               MI_bits=unname(measures["MI_bits"]), stringsAsFactors=FALSE)
  })
  assoc_boot[[b]] <- dplyr::bind_rows(one)
}
assoc_draws <- dplyr::bind_rows(assoc_boot)
save_csv(assoc_draws,"15_association_term_bootstrap_draws.csv")

assoc_ci <- assoc_draws %>% group_by(period) %>% summarise(
  n_valid=sum(is.finite(V_bias_corrected)),
  V_boot_low=ci(V_bias_corrected)[1],
  V_boot_high=ci(V_bias_corrected)[2],
  .groups="drop"
)
assoc_metrics <- left_join(assoc_metrics,assoc_ci,by="period")
save_csv(assoc_metrics,"16_period_associations_with_CI.csv")

# A paired difference in association strength, not a comparison of p-values.
# Compare first well-supported period to last pre-2020 period.
pa <- "1900-1949"; pb <- "1980-2019"
wide_boot <- assoc_draws %>% select(replicate,period,V_bias_corrected) %>%
  pivot_wider(names_from=period,values_from=V_bias_corrected)
delta <- wide_boot[[pb]]-wide_boot[[pa]]
delta_ci <- ci(delta)
a_old <- assoc_metrics$V_bias_corrected[match(pa,assoc_metrics$period)]
a_new <- assoc_metrics$V_bias_corrected[match(pb,assoc_metrics$period)]
change <- tibble(
  period_earlier=pa,period_later=pb,earlier_V=a_old,later_V=a_new,
  delta_V=a_new-a_old,
  boot_valid=sum(is.finite(delta)), bootstrap_low=delta_ci[1],bootstrap_high=delta_ci[2]
)
change$interpretation <- if(is.finite(delta_ci[1]) && is.finite(delta_ci[2])) {
  if(delta_ci[1]>0 || delta_ci[2]<0) "CI_excludes_zero" else "CI_includes_zero"
} else "insufficient_bootstrap_support"
save_csv(change,"17_period_association_change_bootstrap.csv")

# Alternate period-activity threshold: >=1 eligible active decade instead of
# >=50%. Used to assess the dependence on a time-block aggregation choice.
alt_rows <- list()
for(alt in c(0.25,0.50,0.75)) {
  for(pn in period_order) {
    dd <- term_period %>% filter(period==pn,eligible_for_period,
                                 pathway %in% c("source_form","pure_calque"),
                                 activity_share>=alt)
    q <- assoc_from_table(make_assoc_tab(dd))
    alt_rows[[paste(alt,pn)]] <- data.frame(period=pn,minimum_share=alt,n=nrow(dd),
      V_bias_corrected=unname(q["V_bias_corrected"]),stringsAsFactors=FALSE)
  }
}
save_csv(dplyr::bind_rows(alt_rows),"18_period_activity_definition_sensitivity.csv")

# 6. FIGURES ---------------------------------------------------------------
COLORS <- c("Observed (variable N)"="#0072B2","Rarefied (N=20)"="#D55E00")
plot_div <- bind_rows(
  structure_decade %>% transmute(decade, value=effective_domains,
     low=effective_domains_boot_low,high=effective_domains_boot_high,
     series="Observed (variable N)"),
  rarefied %>% transmute(decade,value=effective_domains_mean,
     low=effective_domains_low,high=effective_domains_high,
     series=paste0("Rarefied (N=",RAREFY_N,")"))
)
# Match a user-adjusted RAREFY_N without relying on a fixed legend key.
col_dynamic <- setNames(c("#0072B2","#D55E00"),unique(plot_div$series))
p1 <- ggplot(plot_div,aes(x=decade,y=value,color=series,fill=series)) +
  geom_ribbon(aes(ymin=low,ymax=high),alpha=0.12,linetype=0,na.rm=TRUE) +
  geom_line(linewidth=0.9,na.rm=TRUE) + geom_point(size=1.4,na.rm=TRUE) +
  scale_color_manual(values=col_dynamic) + scale_fill_manual(values=col_dynamic) +
  scale_x_continuous(breaks=seq(1800,2010,20)) +
  labs(x="Decade", y="Effective number of cultural domains",
       color="Series",fill="Series") +
  theme_bw(base_size=12) + theme(legend.position="bottom",panel.grid.minor=element_blank())

flow_long <- flow %>% select(decade,retained_active,first_activation,reactivated,
                             newly_observable_active) %>%
  pivot_longer(-decade,names_to="component",values_to="n")
flow_colors <- c("retained_active"="#0072B2","first_activation"="#009E73",
                 "reactivated"="#E69F00","newly_observable_active"="#CC79A7")
p2 <- ggplot(flow_long,aes(x=decade,y=n,fill=component)) +
  geom_col(width=8) +
  geom_line(data=flow,aes(x=decade,y=active_stock,group=1),
            inherit.aes=FALSE,linewidth=0.9,color="black") +
  scale_fill_manual(values=flow_colors) +
  scale_x_continuous(breaks=seq(1800,2010,20)) +
  labs(x="Decade",y="Active terms",fill="Contributing state") +
  theme_bw(base_size=12) + theme(legend.position="bottom",panel.grid.minor=element_blank())

p3 <- ggplot(assoc_metrics,aes(x=period,y=V_bias_corrected,group=1)) +
  geom_line(color="#0072B2",linewidth=0.8) +
  geom_pointrange(aes(ymin=V_boot_low,ymax=V_boot_high),color="#0072B2",na.rm=TRUE) +
  geom_text(aes(label=if_else(inference_status=="inference_allowed","","sparse")),
            vjust=-1.2,size=3.7,na.rm=TRUE) +
  labs(x="Pre-specified period",y="Bias-corrected Cramer's V") +
  coord_cartesian(ylim=c(0,1)) +
  theme_bw(base_size=12) + theme(panel.grid.minor=element_blank())

stock_long <- flow %>% select(decade,eligible_terms,active_stock) %>%
  pivot_longer(-decade,names_to="series",values_to="n")
p4 <- ggplot(stock_long,aes(decade,n,color=series)) + geom_line(linewidth=1) +
  geom_point(size=1.4) + scale_color_manual(values=c(eligible_terms="#D55E00",active_stock="#0072B2")) +
  scale_x_continuous(breaks=seq(1800,2010,20)) +
  labs(x="Decade",y="Number of terms",color="Stock") +
  theme_bw(base_size=12) + theme(legend.position="bottom",panel.grid.minor=element_blank())

save_plot <- function(p,stem,width=10,height=5.6) {
  ggsave(file.path(OUT_DIR,paste0(stem,".png")),plot=p,width=width,height=height,dpi=450,bg="white")
  ggsave(file.path(OUT_DIR,paste0(stem,".pdf")),plot=p,width=width,height=height,bg="white")
}
save_plot(p1,"Figure_01_diversity_observed_rarefied")
save_plot(p2,"Figure_02_active_stock_flow")
save_plot(p3,"Figure_03_dynamic_pathway_domain_association",width=9,height=5.4)
save_plot(p4,"Figure_04_active_and_eligible_stocks")

# Familiar seven-decade stacked composition chart, for descriptive reading.
selected_decades <- c(1800L,1810L,1820L,1900L,1950L,2000L,2010L)
comp_plot <- domain_decade %>% filter(decade %in% selected_decades)
p5 <- ggplot(comp_plot,aes(x=factor(decade),y=domain_share,fill=cultural_domain)) +
  geom_col(width=0.80) +
  scale_y_continuous(labels=function(x)paste0(round(x*100),"%"),limits=c(0,1),expand=c(0,0)) +
  labs(x="Complete decade",y="Share of active terms",fill="Cultural domain") +
  theme_bw(base_size=11) +
  theme(legend.position="right",panel.grid.minor=element_blank())
save_plot(p5,"Figure_05_selected_decade_composition",width=12,height=6.3)

# 7. AUDIT + REPORT ---------------------------------------------------------
flags <- tibble(
  check=c("annual_rows","unique_terms","full_decades","domain_count",
          "stock_flow_identity","period1_path_support","last_period_path_support",
          "min_rarefaction_active","period_bootstrap_valid",
          "data_2020_2022_not_mixed_into_full_decades"),
  value=c(as.character(nrow(annual)),as.character(nrow(meta)),
          as.character(length(ALL_DECADES)),as.character(length(ALL_DOMAINS)),
          as.character(all(abs(flow$reconciliation_error[is.finite(flow$reconciliation_error)])<1e-9)),
          assoc_metrics$inference_status[1],
          assoc_metrics$inference_status[nrow(assoc_metrics)],
          as.character(sum(structure_decade$n_active>=RAREFY_N)),
          as.character(sum(is.finite(delta))),"TRUE")
)
save_csv(flags,"19_quality_flags.csv")

caveats <- c(
  "SYSTEMS REANALYSIS - INTERPRETATION / PRE-REGISTRATION NOTES",
  "================================================================",
  "1. This is the 154-term CURATED sample, not the full English lexicon.",
  "2. Historical first attestation is NOT inferred from first positive Ngram string.",
  "3. Only 10/10 valid-year coverage permits a term-decade state; all earlier",
  "   (semantically invalid or truncated) years are NOT observable, not inactive.",
  "4. Active = >=3 positive years / 10 (main); >=2 and >=4 are sensitivities.",
  "5. Newly observable active != newly borrowed. First activation is observed",
  "   only after a complete eligible decade of inactivity.",
  "6. The full-sample eligible stock grows over time because validity starts",
  "   differ; inspect Figure 04 and the fixed-1900 cohort before claiming growth.",
  "7. Rarefied curves use a fixed number of active TERMS (without replacement).",
  "   Bootstrap intervals resample terms; neither removes original lexicon bias.",
  "8. A cultural-domain x pathway table is an association structure, NOT a",
  "   network of interactions between words. No feedback mechanism is tested.",
  "9. Period associations count each term once and require >=2 eligible full",
  "   decades and activity in >=50% of those eligible decades.",
  "10. Sparse periods are DESCRIPTIVE ONLY; no Monte Carlo inference is reported.",
  "11. 2020-2022 is a partial 3-year snapshot and is NOT mixed into full decades.",
  "12. NO causal claims about cultural transmission, adaptation, or self-organization.",
  "13. The new full-decade activity rule can differ from the old RQ1 manuscript.",
  "14. Do not decide journal fit solely by significance; examine structural",
  "    effect size, fixed-cohort stability, coverage, and term bootstrap CIs."
)
write_report(caveats,"00_METHOD_AND_INTERPRETATION_NOTES.txt")

summary_lines <- c(
  "SYSTEMS REANALYSIS SUMMARY",
  "==========================",
  paste0("Source: ", normalizePath(INPUT_FILE,winslash="/",mustWork=FALSE)),
  paste0("Annual rows: ",nrow(annual)),
  paste0("Distinct terms: ",nrow(meta)),
  paste0("Full decades: ",length(ALL_DECADES)," (1800-2019)"),
  paste0("Activity rule: ",ACTIVE_POSITIVE_YEARS," positive years in a FULL 10-year window"),
  paste0("Fixed cohort eligible in ",FIXED_COHORT_DECADE,": ",length(cohort_ids)," terms"),
  paste0("Rarefaction: n=",RAREFY_N,", B=",B_RAREFY),
  paste0("Period activity: >=",PERIOD_MIN_FULL_DECADES," eligible full decades; active share >=",PERIOD_ACTIVE_SHARE),
  "",
  "ACTIVE / ELIGIBLE DECADE STOCKS:",
  paste(capture.output(print(as.data.frame(flow %>% select(decade,eligible_terms,active_stock,
    retained_active,first_activation,reactivated,newly_observable_active,became_inactive)),
    row.names=FALSE)),collapse="\n"),
  "",
  "PERIOD ASSOCIATION SUPPORT:",
  paste(capture.output(print(as.data.frame(assoc_metrics %>% select(period,n_binary_terms,n_source_form,
    n_pure_calque,V_bias_corrected,MI_bits,inference_status)),row.names=FALSE)),collapse="\n"),
  "",
  "TERM-BOOTSTRAP ASSOCIATION CHANGE (1900-1949 vs 1980-2019):",
  paste(capture.output(print(change)),collapse="\n"),
  "",
  paste0("Rarefaction available for ",sum(structure_decade$n_active>=RAREFY_N),
         " of ",length(ALL_DECADES)," full decades."),
  "Stock-flow reconciliation: ",
  as.character(all(abs(flow$reconciliation_error[is.finite(flow$reconciliation_error)])<1e-9)),
  "",
  "READ 00_METHOD_AND_INTERPRETATION_NOTES.txt BEFORE interpreting results."
)
write_report(summary_lines,"00_SYSTEMS_RESULTS_SUMMARY.txt")
capture.output(sessionInfo(), file=file.path(OUT_DIR,"sessionInfo.txt"))

# MD5 file list for version control (no dependency beyond base R).
exported <- list.files(OUT_DIR,full.names=TRUE,recursive=FALSE)
exported <- exported[file.info(exported)$isdir %in% FALSE]
manifest <- tibble(filename=basename(exported),bytes=as.numeric(file.info(exported)$size),
                   md5=unname(tools::md5sum(exported)))
save_csv(manifest,"20_OUTPUT_MANIFEST.csv")

# Optional single ZIP to upload in ChatGPT. 'zip' normally installs as a
# Windows binary; failure here does NOT affect any analysis results.
zip_path <- file.path(dirname(OUT_DIR),paste0(basename(OUT_DIR),".zip"))
if(requireNamespace("zip",quietly=TRUE)) {
  zip_ok <- tryCatch({
    zip::zipr(zipfile=zip_path,files=basename(OUT_DIR),root=dirname(OUT_DIR))
    TRUE
  },error=function(e) {message("ZIP creation skipped: ",conditionMessage(e));FALSE})
  if(zip_ok) message("ZIP ready: ",zip_path)
} else {
  message("To package outputs into one ZIP, run: install.packages('zip')")
  message("Or right-click the Systems_Reanalysis_Outputs folder in Windows and compress it.")
}
message("\nSYSTEMS ANALYSIS COMPLETED\nOutput folder: ",OUT_DIR)
message("First read: 00_SYSTEMS_RESULTS_SUMMARY.txt")
message("Upload Systems_Reanalysis_Outputs.zip or the main CSV files to continue.")

message("SYSTEMS REANALYSIS FINISHED. Results in: ", OUT_DIR)

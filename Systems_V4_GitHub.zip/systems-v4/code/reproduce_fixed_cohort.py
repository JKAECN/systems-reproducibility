from pathlib import Path
import json
import pandas as pd
import numpy as np
base_dir=Path(__file__).resolve().parent
root=base_dir/'inputs'
grid=pd.read_csv(root/'02_term_decade_panel.csv')
period=pd.read_csv(root/'11_term_period_panel.csv')
base=grid.loc[grid.decade.eq(1900)&grid.eligible,'row_id'].tolist()
pathway=['source_form','pure_calque']
domains=sorted(grid.cultural_domain.unique())
periods=['1800-1899','1900-1949','1950-1979','1980-2019']
mask=period.period_active & period.pathway.isin(pathway)

def counts(df):
    return pd.crosstab(df.pathway,df.cultural_domain).reindex(index=pathway,columns=domains,fill_value=0).to_numpy()

def V(tab):
    t=np.asarray(tab)
    t=t[t.sum(axis=1)>0,:]
    t=t[:,t.sum(axis=0)>0]
    n=t.sum()
    r,c=t.shape
    if n<3 or r<2 or c<2: return np.nan
    exp=np.outer(t.sum(axis=1),t.sum(axis=0))/n
    phi2=((t-exp)**2/exp).sum()/n
    adj=min(r-1-(r-1)**2/(n-1),c-1-(c-1)**2/(n-1))
    return np.sqrt(max(0,phi2-(r-1)*(c-1)/(n-1))/adj) if adj>0 else np.nan

def metrics(df):
    return {'n':len(df),'paths':df.pathway.value_counts().reindex(pathway,fill_value=0).tolist(),'V':float(V(counts(df)))}

result={'fixed':{}}
sub=period[mask & period.row_id.isin(base)]
for name in periods[1:]:
    result['fixed'][name]=metrics(sub[sub.period.eq(name)])

# The same resampled IDs contribute to both periods. Sample all 119 cohort terms.
pair=[periods[1],periods[-1]]
cube=np.zeros((2,len(base),2,len(domains)),dtype=int)
index={id_:i for i,id_ in enumerate(base)}
for z in sub[sub.period.isin(pair)].itertuples():
    cube[pair.index(z.period),index[z.row_id],pathway.index(z.pathway),domains.index(z.cultural_domain)]=1
rng=np.random.default_rng(20261110)
weights=rng.multinomial(len(base),np.full(len(base),1/len(base)),size=5000)
tables=np.einsum('bt,ktpc->kbpc',weights,cube)
vboot=np.array([[V(tab) for tab in period_tabs] for period_tabs in tables])
for i,p in enumerate(pair):
    vals=vboot[i,np.isfinite(vboot[i])]
    result['fixed'][p].update(ci=np.quantile(vals,[.025,.975]).tolist(),n_boot=len(vals))
dif=vboot[1]-vboot[0]; vals=dif[np.isfinite(dif)]
result['fixed_delta']={'d':result['fixed'][pair[1]]['V']-result['fixed'][pair[0]]['V'],'ci':np.quantile(vals,[.025,.975]).tolist(),'n_boot':len(vals)}

print(json.dumps(result,indent=2))

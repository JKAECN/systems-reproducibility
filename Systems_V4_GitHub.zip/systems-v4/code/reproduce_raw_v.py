from pathlib import Path
import numpy as np
import pandas as pd

path = Path(__file__).resolve().parent.parent / 'outputs' / 'B2_component_cell_counts.csv'
cells = pd.read_csv(path)
early, late, early_only, late_only = [
    cells.loc[cells.component.eq(key), 'n'].to_numpy().reshape(9, 2)
    for key in ('early_common', 'late_common', 'early_boundary', 'late_boundary')
]

def raw_v(table):
    table = table[table.sum(axis=1) > 0]
    n = table.sum()
    expected = np.outer(table.sum(axis=1), table.sum(axis=0)) / n
    chi = ((table - expected)**2 / expected).sum()
    return np.sqrt(chi / (n * min(table.shape[0]-1, table.shape[1]-1)))

v00, v10, v01, v11 = map(raw_v, (
    early + early_only, late + early_only, early + late_only, late + late_only
))
activity = ((v10-v00) + (v11-v01)) / 2
membership = ((v01-v00) + (v11-v10)) / 2
assert np.isclose(activity + membership, v11-v00)
print(f'delta={v11-v00:.9f}, activity={activity:.9f}, membership={membership:.9f}')

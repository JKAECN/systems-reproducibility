# 12_SYSTEMS_METHOD_VALIDATION.R
# Systems methodology validation — coverage comparisons, Shapley table
# decomposition, and scenario-based simulation.
# Only BASE R is required. Designed for R 4.4+ / Windows RStudio.
# Author-generated script; test results are diagnostic, not causal claims.

options(stringsAsFactors = FALSE)
set.seed(20261110)

# ---------------- 0. Input and output paths ----------------
find_script_dir <- function() {
  ff <- sys.frames()
  if (length(ff)) {
    for (i in rev(seq_along(ff))) {
      x <- ff[[i]]$ofile
      if (!is.null(x) && nzchar(x) && file.exists(x))
        return(dirname(normalizePath(x, winslash = "/")))
    }
  }
  args <- commandArgs(trailingOnly = FALSE)
  hit <- grep("^--file=", args, value = TRUE)
  if (length(hit)) {
    x <- sub("^--file=", "", hit[1L])
    if (file.exists(x)) return(dirname(normalizePath(x, winslash = "/")))
  }
  getwd()
}
SCRIPT_DIR <- find_script_dir()
INPUT_DIR <- file.path(SCRIPT_DIR, "inputs")
need <- c("02_term_decade_panel.csv", "11_term_period_panel.csv")
if (!all(file.exists(file.path(INPUT_DIR, need)))) {
  message("Cannot locate both input CSVs near script; select 02_term_decade_panel.csv.")
  f <- file.choose()
  INPUT_DIR <- dirname(f)
}
stopifnot(all(file.exists(file.path(INPUT_DIR, need))))

writable <- function(x) {
  dir.create(x, recursive = TRUE, showWarnings = FALSE)
  test <- file.path(x, paste0("_write_test_", Sys.getpid(), ".txt"))
  ok <- tryCatch({ writeLines("ok", test); file.remove(test); TRUE }, error = function(e) FALSE)
  ok
}
OUT <- file.path(SCRIPT_DIR, "outputs_r")
if (!writable(OUT)) OUT <- file.path(path.expand("~"), "Systems_Method_Validation_V2_Output")
if (!writable(OUT)) stop("No writable output folder. Set OUT to a writable path.")
message("OUTPUT DIRECTORY: ", OUT)

save_csv <- function(x, name) {
  utils::write.csv(x, file.path(OUT, name), row.names = FALSE, na = "")
}
log_lines <- character()
log_add <- function(...) { log_lines <<- c(log_lines, paste0(...)) }

p <- utils::read.csv(file.path(INPUT_DIR, need[1L]), check.names = FALSE)
t <- utils::read.csv(file.path(INPUT_DIR, need[2L]), check.names = FALSE)
truth <- function(x) {if (is.logical(x)) return(replace(x, is.na(x), FALSE))
  tolower(as.character(x)) %in% c("true", "t", "1") }
p$eligible <- truth(p$eligible)
p$active <- truth(p$active)
t$eligible_for_period <- truth(t$eligible_for_period)
t$period_active <- truth(t$period_active)
stopifnot(nrow(p) == 3388L, length(unique(p$row_id)) == 154L)
stopifnot(!anyDuplicated(p[c("row_id", "decade")]))

eff_div <- function(x) {
  counts <- table(x)
  if (!length(counts)) return(NA_real_)
  prop <- as.numeric(counts) / sum(counts)
  exp(-sum(prop * log(prop)))
}

# ---------------- A. Boundary-blind vs coverage-aware ----------------
decades <- sort(unique(p$decade))
A1 <- do.call(rbind, lapply(decades, function(yr) {
  d <- p[p$decade == yr, , drop = FALSE]
  naive <- d$n_positive_years >= 3L
  naive[is.na(naive)] <- FALSE
  eligible <- d$eligible
  adjusted <- eligible & naive
  n_el <- sum(eligible)
  data.frame(
    decade=yr, curated_terms=nrow(d), n_eligible=n_el,
    naive_active=sum(naive), corrected_active=sum(adjusted),
    naive_rate_154=sum(naive)/nrow(d),
    coverage_adjusted_rate=if (n_el > 0) sum(adjusted)/n_el else NA_real_,
    partial_window_active=sum(naive & !eligible),
    naive_effective_domains=eff_div(d$cultural_domain[naive]),
    corrected_effective_domains=eff_div(d$cultural_domain[adjusted])
  )
}))
A1$naive_minus_adjusted_rate_pp <- 100*(A1$naive_rate_154-A1$coverage_adjusted_rate)
A1$naive_minus_adjusted_active_n <- A1$naive_active-A1$corrected_active
# Deterministic checks against the archived, frozen naming panel.
stopifnot(A1$naive_active[A1$decade==2010L] == 153L,
          A1$corrected_active[A1$decade==2010L] == 149L,
          A1$n_eligible[A1$decade==2010L] == 150L,
          A1$naive_active[A1$decade==1900L] == 55L,
          A1$n_eligible[A1$decade==1900L] == 119L)
save_csv(A1,"A1_observation_rule_direct_comparison.csv")

A2 <- do.call(rbind, lapply(decades[-1], function(yr) {
  d0 <- p[p$decade == yr-10L, ]
  d1 <- p[p$decade == yr, ]
  ix <- match(d1$row_id,d0$row_id)
  stopifnot(!anyNA(ix))
  e0 <- d0$eligible[ix];e1 <- d1$eligible
  n0 <- d0$n_positive_years[ix] >= 3L
  n1 <- d1$n_positive_years >= 3L
  n0[is.na(n0)] <- FALSE;n1[is.na(n1)] <- FALSE
  c0 <- e0 & n0;c1 <- e1 & n1
  data.frame(decade=yr,
    naive_newly_active=sum(n1 & !n0),naive_lost=sum(!n1 & n0),
    corrected_newly_active_common_eligible=sum(c1 & !c0 & e0),
    corrected_newly_observable_active=sum(c1 & !e0),
    corrected_lost_common_eligible=sum(!c1 & c0 & e1),
    n_active_unqualified_under_naive=sum(n1 & !e1))
}))
save_csv(A2, "A2_naive_vs_coverage_aware_transitions.csv")
log_add("A: 1800 counts naive/corrected/eligible = ", paste(A1[1,c("naive_active","corrected_active","n_eligible")],collapse=" / "))
log_add("A: 2010 counts naive/corrected/eligible = ",paste(A1[nrow(A1),c("naive_active","corrected_active","n_eligible")],collapse=" / "))

# ---------------- B. Shapley decomposition of Cramer's V ----------------
# Fixed labels imply that all changes in this comparison arise from which
# terms are eligible and active. This is an accounting decomposition only.
meta <- unique(p[c("row_id","pathway","cultural_domain")])
meta <- meta[meta$pathway %in% c("source_form", "pure_calque"),]
meta <- meta[order(meta$row_id),]
stopifnot(!anyDuplicated(meta$row_id),nrow(meta)==150L)
paths <- c("source_form","pure_calque")
domains <- sort(unique(p$cultural_domain))
cell <- (match(meta$cultural_domain,domains)-1L)*2L+match(meta$pathway,paths)
N <- nrow(meta);K <- length(domains)*2L

get_period_flags <- function(label) {
  x <- t[t$period == label, , drop=FALSE]
  idx <- match(meta$row_id, x$row_id)
  e <- rep(FALSE,N);a <- rep(FALSE,N)
  ok <- which(!is.na(idx))
  e[ok] <- x$eligible_for_period[idx[ok]]
  a[ok] <- x$period_active[idx[ok]]
  stopifnot(!any(a & !e))
  list(e=e,a=a)
}
b0 <- get_period_flags("1900-1949")
b1 <- get_period_flags("1980-2019")
E0 <- b0$e; E1 <- b1$e; S0 <- b0$a; S1 <- b1$a
shared <- E0 & E1

# Rows are the nine cultural domains, columns the two naming pathways.
cell_table <- function(mask, weight) {
  out <- vapply(seq_len(K),function(j) sum(weight[mask & (cell==j)]), numeric(1L))
  matrix(out, ncol=2L, byrow=TRUE,
         dimnames=list(domains, paths))
}

corrected_v <- function(tab) {
  tab <- tab[rowSums(tab)>0,,drop=FALSE]
  n <- sum(tab)
  if (n<=2L || nrow(tab)<2L || any(colSums(tab)<=0))return(NA_real_)
  expectation <- outer(rowSums(tab),colSums(tab))/n
  chi <- sum((tab-expectation)^2/expectation)
  phi2 <- chi/n
  r <- nrow(tab); k <- ncol(tab)
  phi2corr <- max(0, phi2-(k-1)*(r-1)/(n-1))
  rcorr <- r-(r-1)^2/(n-1)
  kcorr <- k-(k-1)^2/(n-1)
  den <- min(rcorr-1,kcorr-1)
  if (den<=0)return(NA_real_)
  sqrt(phi2corr/den)
}

shapley <- function(w) {
  m0 <- cell_table(shared & S0, w)
  m1 <- cell_table(shared & S1, w)
  l0 <- cell_table(E0 & !E1 & S0, w)
  l1 <- cell_table(E1 & !E0 & S1, w)
  v00 <- corrected_v(m0+l0)
  v10 <- corrected_v(m1+l0)
  v01 <- corrected_v(m0+l1)
  v11 <- corrected_v(m1+l1)
  if (!all(is.finite(c(v00,v10,v01,v11)))) {
    return(c(V_early=v00,V_late=v11,delta_V=v11-v00,
             common_activity_component=NA_real_,membership_component=NA_real_,
             reconciliation=NA_real_))
  }
  common <- 0.5*((v10-v00)+(v11-v01))
  member <- 0.5*((v01-v00)+(v11-v10))
  c(V_early=v00,V_late=v11,delta_V=v11-v00,
    common_activity_component=common,membership_component=member,
    reconciliation=(common+member)-(v11-v00))
}
point <- shapley(rep(1,N))
stopifnot(is.finite(point["reconciliation"]), abs(point["reconciliation"])<1e-10)
stopifnot(abs(unname(point["V_early"])-0.1711933991)<1e-6,
          abs(unname(point["V_late"])-0.3510847667)<1e-6,
          sum(E0 & E1)==117L, sum(E1 & !E0)==26L)
# Note: the stochastic bootstrap and simulation outputs need not match the
# Python reference tables exactly because the random generators differ.
B1 <- as.data.frame(as.list(point))
B1$n_common_eligible <- sum(shared)
B1$n_newly_eligible_late <- sum(E1 & !E0)
B1$n_early_only_eligible <- sum(E0 & !E1)
save_csv(B1,"B1_shapley_table_decomposition_point.csv")

B2 <- do.call(rbind,lapply(names(list(
 early_common=shared&S0,late_common=shared&S1,
 early_boundary=E0&!E1&S0,late_boundary=E1&!E0&S1
)),function(label) {
 mask <- switch(label,early_common=shared&S0,late_common=shared&S1,
              early_boundary=E0&!E1&S0,late_boundary=E1&!E0&S1)
 tab <- cell_table(mask,rep(1,N))
 data.frame(component=label,cultural_domain=rep(domains,each=2L),
            pathway=rep(paths,length(domains)),n=as.vector(t(tab)))
}))
save_csv(B2,"B2_component_cell_counts.csv")

B_BOOT <- 2500L
boot <- matrix(NA_real_,nrow=B_BOOT,ncol=length(point),dimnames=list(NULL,names(point)))
set.seed(20261110)
for (b in seq_len(B_BOOT)) {
  idx <- sample.int(N,size=N,replace=TRUE)
  wt <- tabulate(idx,nbins=N)
  boot[b,] <- shapley(wt)
}
B3 <- data.frame(draw=seq_len(B_BOOT),boot,check.names=FALSE)
save_csv(B3,"B3_shapley_term_bootstrap_draws.csv")
metric_names <- c("delta_V","common_activity_component","membership_component","reconciliation")
B4 <- do.call(rbind,lapply(metric_names,function(m) {
  v <- boot[,m];v <- v[is.finite(v)]
  data.frame(metric=m,point=unname(point[m]),n_valid=length(v),
             n_requested=B_BOOT,valid_share=length(v)/B_BOOT,
             bootstrap_mean=if(length(v))mean(v)else NA_real_,
             ci2_5=if(length(v))unname(quantile(v,.025))else NA_real_,
             ci97_5=if(length(v))unname(quantile(v,.975))else NA_real_)
}))
save_csv(B4,"B4_shapley_term_bootstrap_summary.csv")
log_add("B: V early / late / delta = ",paste(round(point[c("V_early","V_late","delta_V")],4),collapse=" / "))
log_add("B: common activity / membership components = ",paste(round(point[c("common_activity_component","membership_component")],4),collapse=" / "))

# ---------------- C. Scenario validation against known oracle ----------------
# The simulation uses two hypothetical fully observed 10-year periods.
# True activity = >=3 positive annual years.  Hidden early observations
# are NOT necessarily random in the informative-eligibility scenario.
set.seed(20261111)
R <- 1500L
N_SIM <- 154L
scenarios <- data.frame(
 scenario=c("stable_random_eligibility","increase_random_eligibility",
            "decline_random_eligibility","stable_informative_eligibility"),
 p0=c(.65,.40,.75,.65),p1=c(.65,.75,.45,.65),
 selection=c("independent","independent","independent","activity_dependent")
)

synth_activity <- function(n,prob) {
  latent <- runif(n) < prob
  per_year <- ifelse(latent,.72,.03)
  positive_years <- rowSums(matrix(runif(n*10L),nrow=n,ncol=10L) <
     matrix(rep(per_year,10L),nrow=n,ncol=10L))
  positive_years >= 3L
}

S1 <- vector("list",nrow(scenarios)*R)
counter <- 0L
for (s in seq_len(nrow(scenarios))) {
  for (b in seq_len(R)) {
    a0 <- synth_activity(N_SIM,scenarios$p0[s])
    a1 <- synth_activity(N_SIM,scenarios$p1[s])
    if (scenarios$selection[s]=="independent") {
      e0 <- runif(N_SIM)<.55
    } else {
      e0 <- runif(N_SIM) < ifelse(a0,.30,.80)
    }
    e1 <- e0 | (runif(N_SIM)<.90)
    oracle <- mean(a1)-mean(a0)
    naive <- mean(a1&e1)-mean(a0&e0)
    adjusted <- mean(a1[e1])-mean(a0[e0])
    baseline <- mean(a1[e0])-mean(a0[e0])
    counter <- counter+1L
    S1[[counter]] <- data.frame(scenario=scenarios$scenario[s],replicate=b,
      oracle_change=oracle,naive_change=naive,
      coverage_adjusted_change=adjusted,baseline_cohort_change=baseline,
      early_eligible=sum(e0),late_eligible=sum(e1))
  }
}
C1 <- do.call(rbind,S1)
save_csv(C1,"C1_simulation_draws.csv")
C2 <- do.call(rbind,lapply(unique(C1$scenario),function(sc) {
  z <- C1[C1$scenario==sc,]
  do.call(rbind,lapply(c("naive_change","coverage_adjusted_change","baseline_cohort_change"),function(v) {
    error <- z[[v]]-z$oracle_change
    data.frame(scenario=sc,estimator=v,replicates=nrow(z),
      mean_oracle_delta=mean(z$oracle_change),mean_estimated_delta=mean(z[[v]]),
      mean_bias=mean(error),RMSE=sqrt(mean(error^2)),
      material_error_share=mean(abs(error)>=.15),
      false_rise_share=if(grepl("stable",sc))
        mean(z[[v]]>.15 & abs(z$oracle_change)<.10) else NA_real_)
  }))
}))
save_csv(C2,"C2_simulation_performance_summary.csv")

# ---------------- Quick figures and audit ----------------
pdf(file.path(OUT,"Figure_A_observation_coverage.pdf"),width=8,height=5)
plot(A1$decade,A1$naive_rate_154,type="o",pch=16,col="gray40",ylim=c(0,1),
     xlab="Complete-decade start",ylab="Fraction of names classified active",
     main="Boundary-blind vs. eligibility-adjusted activity")
lines(A1$decade,A1$coverage_adjusted_rate,type="o",pch=1,col="steelblue4")
legend("topleft",c("Naive: numerator / all 154 names",
 "Coverage-adjusted: eligible-active / eligible"),
 col=c("gray40","steelblue4"),lty=1,pch=c(16,1),bty="n",cex=.8)
dev.off()

pdf(file.path(OUT,"Figure_B_association_decomposition.pdf"),width=8,height=5)
barplot(point[c("common_activity_component","membership_component","delta_V")],
  names.arg=c("Shared-member\nactivity","Eligible-membership\nchange","Total\nchange"),
  col=c("gray70","gray40","white"),border="black",ylab="Change in bias-corrected Cramer's V",
  main="Descriptive Shapley decomposition (not causal)")
abline(h=0,lwd=1)
dev.off()

summary <- c(
 "SYSTEMS VALIDATION V2 - THREE ANALYTICAL MODULES",
 "================================================",
 paste("R version:",R.version.string),
 paste("Input directory:",normalizePath(INPUT_DIR,winslash="/")),
 paste("Output directory:",normalizePath(OUT,winslash="/")),
 "",
 log_lines,
 "",
 "INTERPRETATION RULES:",
 "A: naive and adjusted rates have different denominators/estimands.",
 "B: Shapley components are exact descriptive accounting for non-linear V, not causes.",
 "B: label categories are fixed; no within-term reclassification is measured.",
 "B: shared-member activity changes and eligibility-membership changes are separated.",
 "B: draw validity is documented; do not suppress wide or zero-crossing intervals.",
 "C: simulation assumptions are specified, with both independent and informative selection.",
 "C: informative eligibility CAN bias coverage-adjusted/fixed-cohort estimates.",
 "C: simulation is a stress test of a measurement rule, not proof of universal validity.",
 "C: .15 is an operational material-error threshold, not a test alpha.",
 "Do not call this analysis pre-registered: it was added after reviewing earlier findings."
)
writeLines(summary,file.path(OUT,"00_VALIDATION_SUMMARY.txt"),useBytes=TRUE)
sink(file.path(OUT,"sessionInfo.txt"));print(sessionInfo());sink()
files <- list.files(OUT,full.names=TRUE)
manifest <- data.frame(filename=basename(files),bytes=as.numeric(file.info(files)$size))
save_csv(manifest,"20_OUTPUT_MANIFEST.csv")
cat("\nVALIDATION FINISHED. Results: ",OUT,"\n",sep="")

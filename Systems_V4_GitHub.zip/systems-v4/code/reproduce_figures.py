"""Rebuild the four V4 article figures from the archived estimates."""
from pathlib import Path
import json

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

project = Path(__file__).resolve().parent.parent
root = project / "outputs" / "longitudinal"
a = json.loads((project / "outputs" / "fixed_cohort_python.json").read_text(encoding="utf-8"))
output_dir = project / "generated" / "figures"
output_dir.mkdir(parents=True, exist_ok=True)
periods=['1900-1949','1980-2019']
late,early=a['fixed'][periods[1]],a['fixed'][periods[0]]
delta=a['fixed_delta']

# Use the original numerical series and the checked cohort contrasts.
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,
                     'axes.spines.top':False,'axes.spines.right':False,
                     'axes.linewidth':.7,'savefig.dpi':600})
def init(ylabel):
    fig,ax=plt.subplots(figsize=(7.25,2.48))
    ax.set_ylabel(ylabel)
    ax.grid(axis='y',color='#e0e0e0',lw=.65)
    ax.set_axisbelow(True)
    return fig,ax
def years(ax):
    ax.set_xlim(1795,2015)
    ax.set_xticks([1800,1840,1880,1920,1960,2010])
    ax.set_xlabel('Decade beginning')
def legend(ax,n=2,y=-.29):
    ax.legend(loc='upper center',bbox_to_anchor=(.5,y),ncol=n,frameon=False,fontsize=8.4,handlelength=2.3)
def save(fig,i):
    fig.savefig(output_dir/f'figure{i}.png',bbox_inches='tight',pad_inches=.1)
    plt.close(fig)
s=pd.read_csv(root/'03_structure_by_decade.csv')
r=pd.read_csv(root/'04_rarefied_diversity_by_decade.csv')
f=pd.read_csv(root/'08_system_stock_flow.csv')
v=pd.read_csv(root/'16_period_associations_with_CI.csv')
fig,ax=init('Number of names')
ax.plot(s.decade,s.n_eligible,'--s',label='Eligible names',color='#B45716',ms=3,lw=1.45,mfc='white')
ax.plot(s.decade,s.n_active,'-o',label='Active names',color='#155D98',ms=3,lw=1.5)
ax.set_ylim(0,160)
years(ax)
legend(ax)
save(fig,1)
fig,ax=init('Effective number of domains')
x=s.decade.to_numpy()
ax.fill_between(x,s.effective_domains_boot_low,s.effective_domains_boot_high,color='#CFE3F3',linewidth=0)
rr=r.dropna(subset=['effective_domains_mean'])
ax.fill_between(rr.decade,rr.effective_domains_low,rr.effective_domains_high,
                facecolor='#EDAC6632',edgecolor='#B45716',hatch='///',linewidth=.35)
ax.plot(x,s.effective_domains,'-o',color='#155D98',lw=1.45,ms=3,label='Observed diversity')
ax.plot(rr.decade,rr.effective_domains_mean,'--s',color='#B45716',lw=1.45,ms=3,mfc='white',
        label='Fixed-size diversity (20 active names)')
ax.set_ylim(1,9)
years(ax)
legend(ax)
save(fig,2)
fig,ax=init('Number of active names')
base=np.zeros(len(f))
for key,label,c,h in [
 ('retained_active','Retained from preceding decade','#2169A5',None),
 ('first_activation','First activation','#DE8B32',None),
 ('reactivated','Reactivation','#56B4A0','...'),
 ('newly_observable_active','Newly observable or baseline','#BC9BCE','///')]:
    ax.bar(f.decade,f[key],bottom=base,width=7.4,color=c,edgecolor='#292929',
           linewidth=.45,hatch=h,label=label)
    base+=f[key].to_numpy()
ax.set_ylim(0,160)
years(ax)
legend(ax,2,-.29)
save(fig,3)
fig,ax=init('Bias-corrected Cramér’s V')
for i,row in enumerate(v.itertuples()):
    x=i if i not in (1,3) else i-.09
    ax.errorbar(x,row.V_bias_corrected,yerr=[[row.V_bias_corrected-row.V_boot_low],[row.V_boot_high-row.V_bias_corrected]],
      color='#155D98',fmt='o',ms=4,capsize=3,lw=1.05,mfc='white' if i==0 else '#155D98',
      label='Full inventory' if i==1 else None)
for i,key in [(1,periods[0]),(3,periods[1])]:
    z=a['fixed'][key]
    ax.errorbar(i+.09,z['V'],yerr=[[z['V']-z['ci'][0]],[z['ci'][1]-z['V']]],color='#B45716',
      fmt='s',mfc='white',ms=4,capsize=3,lw=1.05,label='Fixed 1900 cohort' if i==1 else None)
ax.set_xticks(range(4),['1800–1899\n(sparse support)','1900–1949','1950–1979','1980–2019'])
ax.set_xlim(-.4,3.4)
ax.set_ylim(-.03,.8)
ax.set_xlabel('Historical period')
legend(ax,2,-.33)
save(fig,4)


# Chinese cultural names in English

Data and code for the Systems manuscript *Auditing Change in Historical Naming Records: Observation Eligibility, Membership Decomposition, and Simulation Evidence from Chinese Cultural Names in English, 1800–2019*.

This snapshot accompanies manuscript V4. The curated data contain 27,439 annual Google Books Ngram observations for 154 names. The main analysis uses complete decades from 1800 to 2019. The annual files retain available records through 2022. The annual CSVs contain derived Ngram frequencies and research annotations rather than book texts.

## Files

| Path | Contents |
| --- | --- |
| `data/annual/` | Audited annual records and the alternative observation-boundary dataset |
| `data/audits/` | Chronology evidence, pathway classifications, historical spelling audits, and evidence for examples in the manuscript |
| `code/inputs/` | Frozen term–decade and term–period panels used by the validation scripts |
| `code/` | Main R validation script and Python scripts for the fixed-cohort analysis, uncorrected-V check, and figures |
| `code/legacy/` | Earlier R analysis scripts with repository-relative path settings |
| `outputs/` | Archived validation results and simulation draws, fixed-cohort output, uncorrected-V output, and R session information |
| `outputs/longitudinal/` | Archived decade, stock-flow, diversity, and period association estimates |
| `outputs/term_level/` | Archived term-level results |
| `figures/` | Four 600 dpi figures corresponding to Figures 1–4 |
| `SHA256SUMS.txt` | Checksums for the files in the snapshot |

## Run the validation analyses

Run the following command from the folder containing this README. The main validation script uses base R. The archived outputs were produced in R 4.6.1.

```sh
Rscript code/12_SYSTEMS_METHOD_VALIDATION.R
```

In RStudio, open the script and use **Source**, or run `source("code/12_SYSTEMS_METHOD_VALIDATION.R")` from the repository folder. The script reads the two frozen CSVs in `code/inputs/` and writes to `code/outputs_r/` when that directory is writable. It prints the output location when it runs. The archived files in `outputs/` are the reference for comparison.

The Python checks were run with Python 3.12.14. From the same folder:

```sh
python -m pip install -r requirements.txt
python code/reproduce_fixed_cohort.py
python code/reproduce_raw_v.py
python code/reproduce_figures.py
```

The first two scripts print the results corresponding to `outputs/fixed_cohort_python.json` and `outputs/raw_v_sensitivity.txt`. The figure script uses the archived estimates and saves new files to `generated/figures/`.

## Map the article to the archived outputs

| Article analysis | Archived files |
| --- | --- |
| Historical observation rules and transitions | `outputs/A1_observation_rule_direct_comparison.csv` and `outputs/A2_naive_vs_coverage_aware_transitions.csv` |
| Fixed 1900 cohort contrasts in Table 5 and Figure 4 | `outputs/fixed_cohort_python.json` and `outputs/longitudinal/05_fixed_1900_cohort_structure.csv` for the cohort diversity series |
| Bias-corrected Cramér’s V and its Shapley decomposition in Table 6 | `outputs/B1_shapley_table_decomposition_point.csv` through `outputs/B4_shapley_term_bootstrap_summary.csv` |
| Uncorrected-V sensitivity comparison | `outputs/raw_v_sensitivity.txt` |
| Whole-period masking simulation in Table 7 | `outputs/C1_simulation_draws.csv` and `outputs/C2_simulation_performance_summary.csv` |

The historical partial-window rule and the simulation baseline have separate meanings. The A1/A2 fields prefixed with `naive_` count historical records with at least three positive admitted years, even when fewer than ten years are admitted. The C1/C2 field `naive_change` instead uses the full simulated inventory as its denominator and treats a wholly masked period as inactive.

## Input conventions and earlier stages

The annual files use `row_id` to identify the name. The `year` and `frequency` columns record calendar year and observed Ngram frequency. The term–decade panel records admitted and positive years in `n_recorded_years` and `n_positive_years`. The main rule requires ten admitted years for eligibility and at least three positive years for activity. The term–period panel records eligibility, activity, and the share of active eligible decades for each name and period.

The earlier longitudinal script can be started from the repository folder with `Rscript code/legacy/11_SYSTEMS_REANALYSIS_SUMMARY_FIX.R`. Its input is `data/annual/FINAL_SUBMISSION_ANNUAL_DATA.csv`, and its output folder is `generated/longitudinal/`. Its package requirements are listed in the script and in `outputs/longitudinal/sessionInfo_longitudinal.txt`. The older term-level script is retained to document the upstream curation and analysis. It requires additional source files from that earlier stage. The validation commands above start from the frozen panels and require no new Google Books Ngram query.
